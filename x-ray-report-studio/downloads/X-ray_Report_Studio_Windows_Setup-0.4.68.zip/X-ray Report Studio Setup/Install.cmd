@echo off
setlocal
set "MRI_STUDIO_PACKAGE=%~dp0"
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0Install.ps1"
exit /b %ERRORLEVEL%
